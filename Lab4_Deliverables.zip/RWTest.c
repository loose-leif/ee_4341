/*
** RWTest.c
**
*/
// configuration bit settings, Fcy=72 MHz, Fpb=36 MHz

//#pragma config POSCMOD=XT, FNOSC=PRIPLL
//#pragma config FPLLIDIV=DIV_2, FPLLMUL=MUL_18, FPLLODIV=DIV_1
//#pragma config FPBDIV=DIV_2, FWDTEN=OFF, CP=OFF, BWP=OFF
//#pragma config DEBUG = ON               // Background Debugger Enable (Debugger is Enabled)

// DEVCFG3
#pragma config USERID = 0xFFFF          // Enter Hexadecimal value (Enter Hexadecimal value)
#pragma config FSRSSEL = PRIORITY_7     // Shadow Register Set Priority Select (SRS Priority 7)
#pragma config PMDL1WAY = ON            // Peripheral Module Disable Configuration (Allow only one reconfiguration)
#pragma config IOL1WAY = ON             // Peripheral Pin Select Configuration (Allow only one reconfiguration)
#pragma config FUSBIDIO = ON            // USB USID Selection (Controlled by the USB Module)
#pragma config FVBUSONIO = ON           // USB VBUS ON Selection (Controlled by USB Module)

// DEVCFG2
#pragma config FPLLIDIV = DIV_2         // PLL Input Divider (2x Divider)
#pragma config FPLLMUL = MUL_18         // PLL Multiplier (18x Multiplier)
#pragma config UPLLIDIV = DIV_12        // USB PLL Input Divider (12x Divider)
#pragma config UPLLEN = OFF             // USB PLL Enable (Disabled and Bypassed)
#pragma config FPLLODIV = DIV_1         // System PLL Output Clock Divider (PLL Divide by 1)

// DEVCFG1
#pragma config FNOSC = PRIPLL           // Oscillator Selection Bits (Primary Osc w/PLL (XT+,HS+,EC+PLL))
#pragma config FSOSCEN = ON             // Secondary Oscillator Enable (Enabled)
#pragma config IESO = ON                // Internal/External Switch Over (Enabled)
#pragma config POSCMOD = XT             // Primary Oscillator Configuration (XT osc mode)
#pragma config OSCIOFNC = OFF           // CLKO Output Signal Active on the OSCO Pin (Disabled)
#pragma config FPBDIV = DIV_2           // Peripheral Clock Divisor (Pb_Clk is Sys_Clk/2)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Clock Switch Disable, FSCM Disabled)
#pragma config WDTPS = PS1048576        // Watchdog Timer Postscaler (1:1048576)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable (Watchdog Timer is in Non-Window Mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled (SWDTEN Bit Controls))
#pragma config FWDTWINSZ = WINSZ_25     // Watchdog Timer Window Size (Window Size is 25%)

// DEVCFG0
#pragma config DEBUG = OFF               // Background Debugger Enable 
#pragma config JTAGEN = ON              // JTAG Enable (JTAG Port Enabled)
#pragma config ICESEL = ICS_PGx1        // ICE/ICD Comm Channel Select (Communicate on PGEC1/PGED1)
#pragma config PWP = OFF                // Program Flash Write Protect (Disable)
#pragma config BWP = OFF                // Boot Flash Write Protect bit (Protection Disabled)
#pragma config CP = OFF                 // Code Protect (Protection Disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "SDMMC.h"
#include <stdio.h>
#include <string.h>
#include <xc.h>

#define START_ADDRESS 0 // start block address
#define N_BLOCKS 1 // number of blocks 

#define LED3 _RD2  // visual feedback about SD usage status - fail
#define LED2 _RD1  // visual feedback about SD usage status - pass
//#define SW1 _RD6

 void delay(int ms){
    int i = 0;
    while(i < 4900*ms){
        asm("NOP");
        i++;
    }
 } // add your delay function here
 
 void system_reg_unlock(void)
{
    SYSKEY = 0x12345678;
    SYSKEY = 0xAA996655;
    SYSKEY = 0x556699AA;
}

void system_reg_lock(void)
{
    SYSKEY = 0x00000000; 
}

void uart1_setup(void)
{   
    // BRGH OFF; UEN TX_RX; 
    U1MODEbits.BRGH = 0b0;
    U1MODEbits.UEN = 0b00;

    // BaudRate = 9600; Frequency = 40000000 Hz; BRG 259; 
    U1BRG = 233;

    // Enable transmit
    U1STAbits.UTXEN = 1;
    // Enable receive
    U1STAbits.URXEN = 1;
    
    // Enable UART (ON bit)
    U1MODEbits.ON = 1;

    __XC_UART = 1;              // Code is configured to use UART1 for printf()
}
 
main(void){

    system_reg_unlock();            // unlock PPS
    CFGCONbits.IOLOCK = 0;    
    
    U1RXRbits.U1RXR = PORTFbits.RF4;
    RPF5Rbits.RPF5R =  0b0011;  //U1TX 
    
    SDI1Rbits.SDI1R = 0b1010;  // map RC4 to SDI1
   
    RPD9Rbits.RPD9R = 0b0111; // map SS1 to RD9
    RPD0Rbits.RPD0R = 0b1000; // map SDO1 to RD0
    
    
    CFGCONbits.IOLOCK = 1;          // lock   PPS
    system_reg_lock();     
    // set RD1 and RD2 as outputs:
    
    TRISD = 0xFFF9;
    TRISB = 0x0000;
    TRISF = 0x313F;
    
    LED3 = 0;
    LED2 = 0;
    
    LBA addr;
    int i, j, r;
    uart1_setup();
    
    // 1. initialize data
    initData();
    printf("InitData Done\n\r");
    // 2. initialize SD/MMC module
    initSD();
    printf("InitSD Done\n\r");
    
    // 3. fill the buffer with pattern
    for( i=0; i<B_SIZE; i++)
        data[i]= i;   
    printf("Buffer Filled\n\r");
    // 4. wait for the card to be inserted
    while( !getCD()); // check CD switch
        delay(100); // wait contacts de-bounce
        
    printf("CD\n\r");
    if ( initMedia()) // init card
    { // if error code returned
        printf("Media Init Error\n\r");
        goto End;
    } 

    // 5. fill 16 groups of N_BLOCK sectors with data
//    LED1 = 1; // SD card in use 
    addr = START_ADDRESS;
    for( j=0; j<16; j++)
    {
        for( i=0; i<N_BLOCKS; i++)
        {
            if (!writeSECTOR( addr+i*j, data))
            { // writing failed
                printf("Write failed in Nblock init\n\r");
                goto End;
            }
        } // i
     } // j
    
    printf("Finished NBlock Init\n\r");
    // 6. verify the contents of each sector written
    addr = START_ADDRESS;
    for( j=0; j<16; j++)
    {
        for( i=0; i<N_BLOCKS; i++)
        { // read back one block at a time
            if (!readSECTOR( addr+i*j, buffer))
            { // reading failed
                printf("sector reading failed\n\r");
                goto End;
            }
            // verify each block content
            if ( memcmp( data, buffer, B_SIZE))
            { // mismatch
                printf("Mismatch\n\r");
                goto End;
            }
       } // i
    } // j 
    printf("Completed init\n\r");
    
    // 7. indicate successful execution
    LED3 = 1;
   
    if (!writeSECTOR(START_ADDRESS, "Wow, I'm writing to an SD Card." ))
    { // writing failed
        printf("Write failed for test\n\r");
        goto End;
    }
    
    if (!readSECTOR(START_ADDRESS, buffer))
    { // reading failed
        printf("sector reading failed\n\r");
        goto End;
    }
    
    printf("%s\n\r", buffer);
    // main loop
    while(1);
    
    

	
    // If this is reached --> failure   
    End:
    
    LED2 = 1;
    
    // main loop
    while(1);
}